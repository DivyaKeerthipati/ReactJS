import React from 'react'

const Header = (props) => {
    return (
        <>
            <h1>Task Manager</h1>
            <hr />
        </>
    )
}

export default Header