export const baseUrl = 'http://localhost:3001'
export const taskUrl = baseUrl + '/tasks'