import React, { Component } from 'react'

class Login extends Component {
    render(){
        return <p>Login works!</p>
    }
}

export default Login