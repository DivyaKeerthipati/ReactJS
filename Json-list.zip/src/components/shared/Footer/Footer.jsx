import React from 'react'

const Footer = (props) => {
    return (
        <>
            <hr />
            <small>&copy; Indus</small>
        </>
    )
}

export default Footer