import React, { Component } from 'react'

class Register extends Component {
    render(){
        return <p>Register works!</p>
    }
}

export default Register